﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace ProvaEmerson2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Splash splash = new Splash();
            splash.Show();
            Application.DoEvents();
            Thread.Sleep(3000);
            splash.Close();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double SalarioFixo, QtdVendas, valorfinal, ValorpVenda;
            QtdVendas = Convert.ToDouble(txtQtdVendas.Text);
            SalarioFixo = Convert.ToDouble(txtSalarioFixo.Text);

            if (QtdVendas == 1 && QtdVendas > 5)
            {
                ValorpVenda = 40;
                valorfinal = SalarioFixo + (ValorpVenda * QtdVendas);
                lblResultado.Text = Convert.ToString(valorfinal);
            }
            else if (QtdVendas == 5 && QtdVendas < 15)
            {
                ValorpVenda = 50;
                valorfinal = SalarioFixo + (ValorpVenda * QtdVendas);
                lblResultado.Text = Convert.ToString(valorfinal);
            }
            else if (QtdVendas < 15)
            {
                ValorpVenda = 70;
                valorfinal = SalarioFixo + (ValorpVenda * QtdVendas);
                lblResultado.Text = Convert.ToString(valorfinal);
            }


        }

        private void txtSalarioFixo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)
            {
                e.Handled = true;
            }
        }

        private void txtQtdVendas_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)
            {
                e.Handled = true;
            }
        }
    }
}
